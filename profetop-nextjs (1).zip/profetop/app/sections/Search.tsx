'use client'
import { useState } from 'react'
import { categories } from './data'

export function SearchBar() {
  const [active, setActive] = useState('Primaria')
  const filters = ['Primaria', 'Secundaria', 'Gratis', '★ Top']
  return (
    <div className="reveal" style={{ padding: '0 5%', marginTop: -32, position: 'relative', zIndex: 10 }}>
      <div style={{
        background: 'white', borderRadius: 'var(--radius-xl)',
        boxShadow: 'var(--shadow-lg)',
        padding: '20px 24px',
        display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap',
      }}>
        <div style={{
          flex: 1, minWidth: 200,
          display: 'flex', alignItems: 'center', gap: 10,
          background: 'var(--cream)', borderRadius: 'var(--radius-md)',
          padding: '10px 16px',
        }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--ink-light)" strokeWidth="2">
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
          </svg>
          <input type="search" placeholder="Buscar recursos: fichas, exámenes, presentaciones..." style={{
            border: 'none', background: 'none', fontFamily: "'DM Sans', sans-serif",
            fontSize: 15, color: 'var(--ink)', width: '100%', outline: 'none',
          }}/>
        </div>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {filters.map(f => (
            <button key={f} onClick={() => setActive(f)} style={{
              padding: '7px 14px', borderRadius: 20, fontSize: 13, fontWeight: 500,
              border: `1.5px solid ${active === f ? 'var(--red)' : 'var(--cream-dark)'}`,
              background: active === f ? 'var(--red-light)' : 'white',
              color: active === f ? 'var(--red)' : 'var(--ink-mid)',
              cursor: 'pointer', whiteSpace: 'nowrap', transition: 'all .2s',
            }}>{f}</button>
          ))}
        </div>
        <button style={{
          background: 'var(--red)', color: 'white', border: 'none',
          padding: '11px 22px', borderRadius: 'var(--radius-md)',
          fontSize: 14, fontWeight: 500, cursor: 'pointer', whiteSpace: 'nowrap',
        }}>Buscar</button>
      </div>
    </div>
  )
}

export function CatNav() {
  const [active, setActive] = useState('primaria')
  return (
    <div className="reveal" style={{
      padding: '40px 5% 0',
      display: 'flex', gap: 8, overflowX: 'auto', scrollbarWidth: 'none',
    }}>
      {categories.map(cat => (
        <button key={cat.id} onClick={() => {
          setActive(cat.id)
          document.getElementById(cat.id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
        }} style={{
          padding: '9px 18px', borderRadius: 20, fontSize: 14, fontWeight: 500,
          border: `1.5px solid ${active === cat.id ? 'var(--red)' : 'var(--cream-dark)'}`,
          background: active === cat.id ? 'var(--red)' : 'white',
          color: active === cat.id ? 'white' : 'var(--ink-mid)',
          cursor: 'pointer', whiteSpace: 'nowrap', flexShrink: 0, transition: 'all .2s',
        }}>{cat.icon} {cat.title.split(' ').slice(1).join(' ')}</button>
      ))}
    </div>
  )
}
