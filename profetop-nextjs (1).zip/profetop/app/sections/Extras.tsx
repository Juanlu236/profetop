'use client'
import { useState } from 'react'

export function SellBanner() {
  return (
    <div id="vender" className="reveal" style={{
      margin: '0 5% 60px',
      borderRadius: 'var(--radius-xl)',
      background: 'linear-gradient(135deg, var(--red-deep) 0%, var(--red-dark) 50%, var(--red) 100%)',
      padding: 'clamp(40px,5vw,56px) 6%',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      gap: 40, flexWrap: 'wrap',
      position: 'relative', overflow: 'hidden',
    }}>
      <div style={{
        position: 'absolute', right: '5%', top: '50%', transform: 'translateY(-50%)',
        fontFamily: "'DM Serif Display', serif",
        fontSize: 180, color: 'rgba(255,255,255,.06)',
        pointerEvents: 'none', userSelect: 'none',
      }}>★</div>
      <div style={{ position: 'relative', zIndex: 1, maxWidth: 520 }}>
        <div style={{ fontSize: 12, fontWeight: 600, letterSpacing: '.1em', textTransform: 'uppercase', color: 'rgba(255,255,255,.6)', marginBottom: 10 }}>Para docentes vendedores</div>
        <h2 style={{ fontFamily: "'DM Serif Display', serif", fontSize: 'clamp(24px,3.5vw,40px)', color: 'white', lineHeight: 1.2, marginBottom: 12 }}>
          Tus materiales merecen<br/><em style={{ fontStyle: 'italic', color: 'rgba(255,220,220,1)' }}>ser reconocidos</em>
        </h2>
        <p style={{ fontSize: 15, color: 'rgba(255,255,255,.7)', lineHeight: 1.7, marginBottom: 24 }}>
          Sube los recursos que ya preparas para tus clases, pon el precio que quieras y empieza a ganar. Nosotros gestionamos los pagos.
        </p>
        <div style={{ display: 'flex', gap: 32, flexWrap: 'wrap' }}>
          {['Crea tu cuenta gratis', 'Sube tu recurso y ponle precio', 'Cobra el 85% cada mes'].map((txt, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
              <div style={{
                width: 24, height: 24, borderRadius: '50%',
                background: 'rgba(255,255,255,.15)', color: 'white',
                fontSize: 12, fontWeight: 600,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0, marginTop: 1,
              }}>{i + 1}</div>
              <span style={{ fontSize: 13, color: 'rgba(255,255,255,.7)', lineHeight: 1.5 }}>{txt}</span>
            </div>
          ))}
        </div>
      </div>
      <div style={{ position: 'relative', zIndex: 1, display: 'flex', gap: 12, flexWrap: 'wrap' }}>
        <a href="#" style={{ padding: '13px 28px', borderRadius: 'var(--radius-lg)', background: 'white', color: 'var(--red-dark)', fontSize: 16, fontWeight: 500, textDecoration: 'none', boxShadow: '0 4px 20px rgba(0,0,0,.2)' }}>
          Crear cuenta gratis ↗
        </a>
        <a href="#" style={{ padding: '13px 28px', borderRadius: 'var(--radius-lg)', background: 'transparent', color: 'white', border: '1.5px solid rgba(255,255,255,.5)', fontSize: 16, fontWeight: 500, textDecoration: 'none' }}>
          Ver cómo funciona
        </a>
      </div>
    </div>
  )
}

export function Testimonials() {
  const items = [
    { text: 'Mis alumnos de 4.º han entendido las fracciones mucho mejor que con el libro. Las fichas son clarísimas y el precio es imbatible.', name: 'Laura Martínez', role: 'Maestra de Primaria · Sevilla', initials: 'LM', color: 'var(--red)' },
    { text: 'Llevo 3 meses vendiendo mis apuntes de Física y ya ingreso más de 200 € al mes. No me lo podía creer. Ojalá hubiera existido antes.', name: 'Jordi Puig', role: 'Profesor de Secundaria · Barcelona', initials: 'JP', color: 'var(--blue)' },
    { text: 'La búsqueda por asignatura y nivel es perfecta. En 5 minutos encuentro exactamente lo que necesito. Los recursos son de muy buena calidad.', name: 'Ana Villanueva', role: 'Maestra de Inglés · Madrid', initials: 'AV', color: 'var(--green)' },
  ]
  return (
    <section className="reveal" style={{ padding: '80px 5%' }}>
      <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 12, fontWeight: 600, letterSpacing: '.1em', textTransform: 'uppercase', color: 'var(--red)', marginBottom: 12 }}>
        <span style={{ width: 20, height: 2, background: 'var(--red)', borderRadius: 1, display: 'inline-block' }}/>
        Opiniones
      </div>
      <h2 style={{ fontFamily: "'DM Serif Display', serif", fontSize: 'clamp(28px,4vw,48px)', lineHeight: 1.15, marginBottom: 10 }}>
        Lo que dicen <em style={{ fontStyle: 'italic', color: 'var(--red)' }}>los profes</em>
      </h2>
      <p style={{ fontSize: 16, color: 'var(--ink-light)', marginBottom: 40, lineHeight: 1.7 }}>Más de 5.000 docentes ya confían en Profetop.es cada semana.</p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 20 }}>
        {items.map(item => (
          <div key={item.name} style={{ background: 'white', borderRadius: 'var(--radius-lg)', border: '1.5px solid var(--cream-dark)', padding: 24 }}>
            <div style={{ color: '#EF9F27', fontSize: 15, marginBottom: 14 }}>★★★★★</div>
            <p style={{ fontSize: 15, color: 'var(--ink-mid)', lineHeight: 1.7, fontStyle: 'italic', marginBottom: 20 }}>"{item.text}"</p>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 40, height: 40, borderRadius: '50%', background: item.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 15, fontWeight: 600, color: 'white', flexShrink: 0 }}>{item.initials}</div>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink)' }}>{item.name}</div>
                <div style={{ fontSize: 12, color: 'var(--ink-light)' }}>{item.role}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

export function Newsletter() {
  const [email, setEmail] = useState('')
  const [sent, setSent] = useState(false)
  return (
    <section className="reveal" style={{ padding: '80px 5%', textAlign: 'center' }}>
      <div style={{ maxWidth: 520, margin: '0 auto' }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 12, fontWeight: 600, letterSpacing: '.1em', textTransform: 'uppercase', color: 'var(--red)', marginBottom: 12, justifyContent: 'center' }}>
          <span style={{ width: 20, height: 2, background: 'var(--red)', borderRadius: 1, display: 'inline-block' }}/>
          Comunidad
        </div>
        <h2 style={{ fontFamily: "'DM Serif Display', serif", fontSize: 'clamp(28px,4vw,40px)', lineHeight: 1.15, marginBottom: 10 }}>
          Recursos <em style={{ fontStyle: 'italic', color: 'var(--red)' }}>cada semana</em><br/>en tu bandeja
        </h2>
        <p style={{ fontSize: 15, color: 'var(--ink-light)', lineHeight: 1.7 }}>Recibe cada lunes una selección de los mejores recursos nuevos y consejos pedagógicos.</p>
        {sent ? (
          <div style={{ marginTop: 28, padding: '16px 24px', background: 'var(--green-light)', borderRadius: 'var(--radius-lg)', color: 'var(--green)', fontWeight: 500 }}>¡Suscrito! Te escribimos el próximo lunes. 🎉</div>
        ) : (
          <form onSubmit={e => { e.preventDefault(); setSent(true) }} style={{ display: 'flex', gap: 10, marginTop: 28, flexWrap: 'wrap' }}>
            <input
              type="email" value={email} onChange={e => setEmail(e.target.value)}
              placeholder="tu@email.com" required
              style={{ flex: 1, minWidth: 200, padding: '12px 18px', borderRadius: 'var(--radius-md)', border: '1.5px solid var(--cream-dark)', background: 'white', fontFamily: "'DM Sans', sans-serif", fontSize: 15, color: 'var(--ink)', outline: 'none' }}
            />
            <button type="submit" style={{ padding: '12px 22px', borderRadius: 'var(--radius-md)', background: 'var(--red)', color: 'white', border: 'none', fontSize: 14, fontWeight: 500, cursor: 'pointer' }}>Suscribirme</button>
          </form>
        )}
        <p style={{ fontSize: 12, color: 'var(--ink-light)', marginTop: 12 }}>Sin spam. Solo recursos. Baja cuando quieras.</p>
      </div>
    </section>
  )
}

export function Footer() {
  const cols = [
    { title: 'Recursos', links: ['Primaria', 'Secundaria (ESO)', 'Pedagógicos', 'Interdisciplinares', 'Otros recursos'] },
    { title: 'Vender', links: ['Cómo funciona', 'Crear cuenta', 'Política de comisiones', 'Panel del profe', 'Preguntas frecuentes'] },
    { title: 'Plataforma', links: ['Sobre Profetop.es', 'Blog educativo', 'Aviso legal', 'Privacidad', 'Contacto'] },
  ]
  return (
    <footer style={{ background: 'var(--ink)', color: 'white', padding: '60px 5% 32px' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', gap: 48, marginBottom: 48 }} className="footer-grid">
        <div>
          <div style={{ fontFamily: "'DM Serif Display', serif", fontSize: 24, marginBottom: 12 }}>
            <span style={{ color: 'rgba(255,255,255,.9)' }}>Profe</span>
            <span style={{ color: '#F09595' }}>top</span>
            <span style={{ color: 'rgba(255,255,255,.3)', fontSize: 16 }}>.es</span>
          </div>
          <p style={{ fontSize: 14, color: 'rgba(255,255,255,.5)', lineHeight: 1.7, maxWidth: 260 }}>
            El marketplace donde los mejores profes encuentran y venden recursos educativos para primaria y secundaria en España.
          </p>
        </div>
        {cols.map(col => (
          <div key={col.title}>
            <h5 style={{ fontSize: 12, fontWeight: 600, letterSpacing: '.1em', textTransform: 'uppercase', color: 'rgba(255,255,255,.4)', marginBottom: 16 }}>{col.title}</h5>
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 10 }}>
              {col.links.map(l => (
                <li key={l}><a href="#" style={{ textDecoration: 'none', fontSize: 14, color: 'rgba(255,255,255,.6)' }}>{l}</a></li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div style={{ borderTop: '1px solid rgba(255,255,255,.1)', paddingTop: 24, display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
        <p style={{ fontSize: 13, color: 'rgba(255,255,255,.35)' }}>© 2026 Profetop.es — Todos los derechos reservados · Hecho con ❤️ para los profes de España</p>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: 'rgba(163,45,45,.3)', border: '1px solid rgba(163,45,45,.4)', color: '#F09595', fontSize: 12, fontWeight: 600, padding: '4px 12px', borderRadius: 20 }}>
          ★ Comisión vendedor: 85%
        </div>
      </div>
      <style>{`
        @media (max-width: 900px) { .footer-grid { grid-template-columns: 1fr 1fr !important; gap: 32px !important; } }
        @media (max-width: 600px) { .footer-grid { grid-template-columns: 1fr !important; } }
      `}</style>
    </footer>
  )
}
