export type Subject = {
  icon: string
  name: string
  count: number
}

export type Category = {
  id: string
  icon: string
  title: string
  subtitle: string
  color: string
  colorLight: string
  colorMid: string
  subjects: Subject[]
}

export const categories: Category[] = [
  {
    id: 'primaria',
    icon: '🎒',
    title: 'Recursos Primaria',
    subtitle: 'Materiales para 1.º a 6.º de Educación Primaria · 1.247 recursos',
    color: '#A32D2D',
    colorLight: '#FCEBEB',
    colorMid: '#F09595',
    subjects: [
      { icon: '📖', name: 'Lengua Española',       count: 231 },
      { icon: '📐', name: 'Matemáticas',            count: 284 },
      { icon: '🌍', name: 'Conocimiento del Medio', count: 178 },
      { icon: '🎨', name: 'Plástica',               count: 96  },
      { icon: '⚽', name: 'Educación Física',        count: 74  },
      { icon: '🎵', name: 'Música',                  count: 62  },
      { icon: '🇬🇧', name: 'Inglés',                count: 198 },
    ],
  },
  {
    id: 'secundaria',
    icon: '📚',
    title: 'Recursos Secundaria (ESO)',
    subtitle: 'Materiales para 1.º a 4.º de ESO · 1.583 recursos',
    color: '#2D6EA3',
    colorLight: '#E6F1FB',
    colorMid: '#85B7EB',
    subjects: [
      { icon: '📖', name: 'Lengua y Literatura', count: 174 },
      { icon: '📐', name: 'Matemáticas',          count: 196 },
      { icon: '🏛️', name: 'Historia',              count: 118 },
      { icon: '🗺️', name: 'Geografía',             count: 98  },
      { icon: '🔬', name: 'Biología',              count: 112 },
      { icon: '🇬🇧', name: 'Inglés',              count: 161 },
      { icon: '🎵', name: 'Música',                count: 54  },
      { icon: '⚽', name: 'Educación Física',       count: 52  },
      { icon: '🎨', name: 'Plástica y Visual',      count: 67  },
      { icon: '⚙️', name: 'Tecnología',             count: 89  },
      { icon: '💻', name: 'Digitalización',          count: 43  },
      { icon: '📊', name: 'Economía',               count: 38  },
      { icon: '🦉', name: 'Filosofía',              count: 67  },
    ],
  },
  {
    id: 'pedagogicos',
    icon: '🧠',
    title: 'Recursos Pedagógicos',
    subtitle: 'Metodologías, gestión del aula y desarrollo docente · 342 recursos',
    color: '#2D7A52',
    colorLight: '#E1F5EE',
    colorMid: '#9FE1CB',
    subjects: [
      { icon: '🏫', name: 'Gestión del Aula',          count: 87 },
      { icon: '🤝', name: 'Aprendizaje Cooperativo',    count: 64 },
      { icon: '📋', name: 'Evaluación y Rúbricas',      count: 92 },
      { icon: '🌈', name: 'Atención a la Diversidad',   count: 58 },
      { icon: '📅', name: 'Programaciones Didácticas',  count: 41 },
    ],
  },
  {
    id: 'interdisciplinares',
    icon: '🔗',
    title: 'Recursos Interdisciplinares',
    subtitle: 'Proyectos y materiales que cruzan varias asignaturas · 218 recursos',
    color: '#6B4EA3',
    colorLight: '#F0EBFC',
    colorMid: '#C4B0F0',
    subjects: [
      { icon: '🚀', name: 'Proyectos STEAM',            count: 76 },
      { icon: '💡', name: 'Educación en Valores',        count: 54 },
      { icon: '🎯', name: 'Competencias Básicas',        count: 48 },
      { icon: '🗂️', name: 'Aprendizaje por Proyectos',  count: 40 },
      { icon: '📆', name: 'Efemérides y Fechas Clave',   count: 32 },
      { icon: '⭐', name: 'Válido Pri + Sec',            count: 340 },
    ],
  },
  {
    id: 'otros',
    icon: '📦',
    title: 'Otros Recursos',
    subtitle: 'Decoración de aula, recursos para familias y materiales especiales · 184 recursos',
    color: '#2D8A8A',
    colorLight: '#E6F8F8',
    colorMid: '#80D0D0',
    subjects: [
      { icon: '🖼️', name: 'Decoración del Aula',         count: 62 },
      { icon: '✉️', name: 'Comunicación con Familias',    count: 38 },
      { icon: '⏱️', name: 'Para Sustituciones',           count: 44 },
      { icon: '🧭', name: 'Tutorías y Orientación',       count: 40 },
    ],
  },
]

export const featuredResources = [
  { thumb: '📐', bg: '#FCEBEB', subject: 'Matemáticas · Primaria', subjectColor: '#A32D2D', title: 'Fracciones paso a paso — Pack completo', meta: '18 fichas · PDF · 3.º–4.º Pri', price: '2,99 €', rating: '4.9 · 312', top: true },
  { thumb: '📖', bg: '#E6F1FB', subject: 'Lengua · Primaria',       subjectColor: '#2D6EA3', title: 'Comprensión lectora A2 — 10 textos',   meta: '10 textos · PDF · 4.º Pri',   price: null,    rating: '4.7 · 198', top: false },
  { thumb: '🔬', bg: '#E1F5EE', subject: 'Ciencias · Primaria',     subjectColor: '#2D7A52', title: 'El sistema solar — Presentación',       meta: '24 diapositivas · PPT · 5.º', price: '4,50 €', rating: '4.8 · 87',  top: false },
  { thumb: '📊', bg: '#F0EBFC', subject: 'Matemáticas · Multi',     subjectColor: '#6B4EA3', title: 'Introducción a la estadística',         meta: '12 actividades · 6.º & 1.º ESO', price: '3,50 €', rating: '4.7 · 88', top: false },
]
