'use client'
import { useState } from 'react'
import { featuredResources } from './data'

function ResourceCard({ r }: { r: typeof featuredResources[0] }) {
  const [hovered, setHovered] = useState(false)
  return (
    <div style={{
      background: 'white', borderRadius: 'var(--radius-lg)',
      border: `1.5px solid ${hovered ? 'transparent' : 'var(--cream-dark)'}`,
      overflow: 'hidden', cursor: 'pointer',
      transition: 'all .25s',
      transform: hovered ? 'translateY(-4px)' : 'none',
      boxShadow: hovered ? 'var(--shadow-md)' : 'none',
    }}
    onMouseEnter={() => setHovered(true)}
    onMouseLeave={() => setHovered(false)}
    >
      <div style={{
        height: 120, background: r.bg,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 40, position: 'relative',
      }}>
        {r.thumb}
        {r.top && (
          <div style={{
            position: 'absolute', top: 10, right: 10,
            background: 'var(--red)', color: 'white',
            fontSize: 10, fontWeight: 600,
            padding: '3px 8px', borderRadius: 8,
          }}>★ Top</div>
        )}
      </div>
      <div style={{ padding: '14px 16px 16px' }}>
        <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: '.06em', textTransform: 'uppercase', color: r.subjectColor, marginBottom: 6 }}>{r.subject}</div>
        <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink)', lineHeight: 1.35, marginBottom: 8 }}>{r.title}</div>
        <div style={{ fontSize: 12, color: 'var(--ink-light)', marginBottom: 12 }}>{r.meta}</div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          {r.price
            ? <span style={{ fontSize: 16, fontWeight: 700, color: 'var(--ink)' }}>{r.price}</span>
            : <span style={{ fontSize: 12, fontWeight: 600, padding: '4px 10px', borderRadius: 8, background: 'var(--green-light)', color: 'var(--green)' }}>Gratis</span>
          }
          <span style={{ fontSize: 12, color: 'var(--ink-light)' }}>⭐ {r.rating}</span>
        </div>
      </div>
    </div>
  )
}

export default function Featured() {
  return (
    <section className="reveal" style={{ padding: '80px 5%' }}>
      <div style={{
        display: 'inline-flex', alignItems: 'center', gap: 8,
        fontSize: 12, fontWeight: 600, letterSpacing: '.1em', textTransform: 'uppercase',
        color: 'var(--red)', marginBottom: 12,
      }}>
        <span style={{ width: 20, height: 2, background: 'var(--red)', borderRadius: 1, display: 'inline-block' }}/>
        Destacados
      </div>
      <h2 style={{
        fontFamily: "'DM Serif Display', serif",
        fontSize: 'clamp(28px, 4vw, 48px)',
        lineHeight: 1.15, color: 'var(--ink)', marginBottom: 10,
      }}>
        ★ Los más vendidos <em style={{ fontStyle: 'italic', color: 'var(--red)' }}>este mes</em>
      </h2>
      <p style={{ fontSize: 16, color: 'var(--ink-light)', maxWidth: 520, marginBottom: 40, lineHeight: 1.7 }}>
        Recursos elegidos por más de 1.800 profes en toda España.
      </p>
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
        gap: 16,
      }}>
        {featuredResources.map((r, i) => <ResourceCard key={i} r={r} />)}
      </div>
    </section>
  )
}
