'use client'
import { useState } from 'react'
import { categories } from './data'

function SubjectCard({ subject, color, colorLight, colorMid }: {
  subject: { icon: string; name: string; count: number }
  color: string; colorLight: string; colorMid: string
}) {
  const [hovered, setHovered] = useState(false)
  return (
    <a href="#" style={{
      background: hovered ? colorLight : 'white',
      borderRadius: 'var(--radius-md)',
      border: `1.5px solid ${hovered ? colorMid : 'var(--cream-dark)'}`,
      padding: '16px 14px',
      cursor: 'pointer', textDecoration: 'none',
      display: 'flex', flexDirection: 'column', gap: 8,
      transition: 'all .25s',
      transform: hovered ? 'translateY(-3px)' : 'none',
      boxShadow: hovered ? 'var(--shadow-md)' : 'none',
    }}
    onMouseEnter={() => setHovered(true)}
    onMouseLeave={() => setHovered(false)}
    >
      <span style={{ fontSize: 24 }}>{subject.icon}</span>
      <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--ink)', lineHeight: 1.3 }}>{subject.name}</span>
      <span style={{ fontSize: 11, color: 'var(--ink-light)' }}>{subject.count} recursos</span>
      <span style={{
        display: 'inline-block', fontSize: 10, fontWeight: 600,
        padding: '2px 8px', borderRadius: 8, width: 'fit-content',
        background: colorLight, color,
      }}>Ver todos</span>
    </a>
  )
}

export default function Categories() {
  return (
    <>
      {categories.map((cat, i) => (
        <div key={cat.id}>
          <div id={cat.id} className="reveal" style={{ padding: '60px 5% 20px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 28 }}>
              <div style={{
                width: 48, height: 48, borderRadius: 14,
                background: cat.colorLight,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 22, flexShrink: 0,
              }}>{cat.icon}</div>
              <div>
                <h3 style={{
                  fontFamily: "'DM Serif Display', serif",
                  fontSize: 26, color: cat.color, lineHeight: 1.2,
                }}>{cat.title}</h3>
                <p style={{ fontSize: 14, color: 'var(--ink-light)', marginTop: 2 }}>{cat.subtitle}</p>
              </div>
            </div>
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))',
              gap: 10,
            }}>
              {cat.subjects.map(subj => (
                <SubjectCard
                  key={subj.name}
                  subject={subj}
                  color={cat.color}
                  colorLight={cat.colorLight}
                  colorMid={cat.colorMid}
                />
              ))}
            </div>
          </div>
          {i < categories.length - 1 && (
            <div style={{ height: 1, background: 'var(--cream-dark)', margin: '20px 5%' }}/>
          )}
        </div>
      ))}
    </>
  )
}
