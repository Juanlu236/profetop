export default function Hero() {
  return (
    <section style={{
      minHeight: '100vh',
      background: 'linear-gradient(145deg, var(--red-deep) 0%, var(--red-dark) 45%, var(--red) 100%)',
      display: 'flex', flexDirection: 'column', justifyContent: 'center',
      padding: '100px 5% 80px',
      position: 'relative', overflow: 'hidden',
    }}>
      {/* Background texture */}
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23ffffff' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/svg%3E")`,
        pointerEvents: 'none',
      }}/>
      {/* Decorative circles */}
      <div style={{
        position: 'absolute', right: -60, top: '50%', transform: 'translateY(-50%)',
        width: 520, height: 520, borderRadius: '50%',
        background: 'rgba(255,255,255,.04)', border: '1px solid rgba(255,255,255,.06)',
        pointerEvents: 'none',
      }}/>
      <div className="float" style={{
        position: 'absolute', right: 60, top: '50%', transform: 'translateY(-50%)',
        width: 340, height: 340, borderRadius: '50%',
        background: 'rgba(255,255,255,.05)',
        pointerEvents: 'none',
      }}/>
      <div style={{
        position: 'absolute', right: '18%', top: '30%',
        fontSize: 80, opacity: .12, userSelect: 'none', pointerEvents: 'none',
        fontFamily: "'DM Serif Display', serif",
      }}>★</div>

      <div style={{ position: 'relative', zIndex: 1, maxWidth: 680 }}>
        <div className="fade-up" style={{
          display: 'inline-flex', alignItems: 'center', gap: 8,
          background: 'rgba(255,255,255,.12)', border: '1px solid rgba(255,255,255,.2)',
          color: 'rgba(255,255,255,.9)', fontSize: 13, fontWeight: 500,
          padding: '6px 14px', borderRadius: 20, marginBottom: 28,
        }}>
          <span style={{ width: 6, height: 6, background: '#FFD700', borderRadius: '50%', display: 'inline-block' }}/>
          Marketplace educativo · España
        </div>

        <h1 className="fade-up-2" style={{
          fontFamily: "'DM Serif Display', serif",
          fontSize: 'clamp(38px, 6vw, 72px)',
          lineHeight: 1.1, color: 'white', marginBottom: 20,
        }}>
          Los mejores recursos,<br/>
          <em style={{ fontStyle: 'italic', color: 'rgba(255,220,220,1)' }}>para los mejores profes</em>
        </h1>

        <p className="fade-up-3" style={{
          fontSize: 'clamp(16px, 2vw, 19px)', color: 'rgba(255,255,255,.75)',
          maxWidth: 520, lineHeight: 1.7, marginBottom: 36, fontWeight: 300,
        }}>
          Descubre, compra y vende materiales didácticos para primaria y secundaria.
          Todo lo que necesitas para el aula, creado por profes como tú.
        </p>

        <div className="fade-up-4" style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 56 }}>
          <a href="#primaria" style={{
            display: 'inline-flex', alignItems: 'center',
            padding: '13px 28px', borderRadius: 'var(--radius-lg)',
            background: 'white', color: 'var(--red-dark)',
            fontSize: 16, fontWeight: 500, textDecoration: 'none',
            boxShadow: '0 4px 20px rgba(0,0,0,.2)',
            transition: 'all .2s',
          }}>Explorar recursos ↓</a>
          <a href="#vender" style={{
            display: 'inline-flex', alignItems: 'center',
            padding: '13px 28px', borderRadius: 'var(--radius-lg)',
            background: 'transparent', color: 'white',
            border: '1.5px solid rgba(255,255,255,.5)',
            fontSize: 16, fontWeight: 500, textDecoration: 'none',
          }}>Empieza a vender ★</a>
        </div>

        <div className="fade-up-4" style={{ display: 'flex', gap: 40, flexWrap: 'wrap' }}>
          {[
            { num: '+1.800', label: 'Recursos disponibles' },
            { num: '143',    label: 'Profes vendedores' },
            { num: '4.9 ★', label: 'Valoración media' },
          ].map(s => (
            <div key={s.label}>
              <div style={{ fontFamily: "'DM Serif Display', serif", fontSize: 32, color: 'white', lineHeight: 1 }}>{s.num}</div>
              <div style={{ fontSize: 13, color: 'rgba(255,255,255,.6)', marginTop: 2 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
