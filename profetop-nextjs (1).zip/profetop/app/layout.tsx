import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Profetop.es — Los mejores recursos, para los mejores profes',
  description: 'Marketplace educativo donde los docentes españoles compran y venden materiales didácticos para primaria y secundaria.',
  keywords: 'recursos educativos, fichas primaria, materiales secundaria, profes, marketplace educativo, España',
  openGraph: {
    title: 'Profetop.es',
    description: 'Los mejores recursos, para los mejores profes',
    locale: 'es_ES',
    type: 'website',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  )
}
