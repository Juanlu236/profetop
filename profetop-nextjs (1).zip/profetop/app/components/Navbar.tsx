'use client'
import { useState, useEffect } from 'react'

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const links = [
    { href: '#primaria', label: 'Primaria' },
    { href: '#secundaria', label: 'Secundaria' },
    { href: '#pedagogicos', label: 'Pedagógicos' },
    { href: '#interdisciplinares', label: 'Interdisciplinares' },
    { href: '#otros', label: 'Otros' },
  ]

  return (
    <>
      <nav style={{
        position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
        background: 'rgba(251,248,245,.93)',
        backdropFilter: 'blur(12px)',
        borderBottom: '1px solid var(--cream-dark)',
        padding: '0 5%',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        height: 64,
        boxShadow: scrolled ? 'var(--shadow-md)' : 'none',
        transition: 'box-shadow .3s',
      }}>
        <a href="#" style={{ display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none' }}>
          <div style={{
            width: 36, height: 36, borderRadius: 10,
            background: 'var(--red)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
            </svg>
          </div>
          <span style={{ fontFamily: "'DM Serif Display', serif", fontSize: 22 }}>
            <span style={{ color: 'var(--red-dark)' }}>Profe</span>
            <span style={{ color: 'var(--red)' }}>top</span>
            <span style={{ color: 'var(--ink-light)', fontSize: 14 }}>.es</span>
          </span>
        </a>

        {/* Desktop links */}
        <ul style={{ display: 'flex', gap: 4, listStyle: 'none', margin: 0, padding: 0 }}
          className="nav-desktop">
          {links.map(l => (
            <li key={l.href}>
              <a href={l.href} style={{
                textDecoration: 'none', color: 'var(--ink-mid)',
                fontSize: 14, padding: '6px 12px', borderRadius: 'var(--radius-sm)',
                display: 'block', transition: 'color .2s, background .2s',
              }}
              onMouseEnter={e => { (e.target as HTMLElement).style.color = 'var(--red)'; (e.target as HTMLElement).style.background = 'var(--red-light)' }}
              onMouseLeave={e => { (e.target as HTMLElement).style.color = 'var(--ink-mid)'; (e.target as HTMLElement).style.background = 'transparent' }}
              >{l.label}</a>
            </li>
          ))}
        </ul>

        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <a href="#" style={{
            padding: '8px 16px', borderRadius: 'var(--radius-md)',
            border: '1px solid var(--cream-dark)', background: 'transparent',
            color: 'var(--ink-mid)', fontSize: 14, textDecoration: 'none',
            transition: 'all .2s',
          }}>Entrar</a>
          <a href="#vender" style={{
            padding: '8px 16px', borderRadius: 'var(--radius-md)',
            background: 'var(--red)', color: 'white',
            fontSize: 14, fontWeight: 500, textDecoration: 'none',
            boxShadow: '0 2px 8px rgba(163,45,45,.3)',
            transition: 'all .2s',
          }}>Vender ★</a>
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            style={{ display: 'none', flexDirection: 'column', gap: 5, background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}
            className="hamburger"
            aria-label="Menú"
          >
            <span style={{ display: 'block', width: 22, height: 2, background: 'var(--ink)', borderRadius: 2 }}/>
            <span style={{ display: 'block', width: 22, height: 2, background: 'var(--ink)', borderRadius: 2 }}/>
            <span style={{ display: 'block', width: 22, height: 2, background: 'var(--ink)', borderRadius: 2 }}/>
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      {menuOpen && (
        <div style={{
          position: 'fixed', top: 64, left: 0, right: 0, zIndex: 99,
          background: 'var(--cream)', borderBottom: '1px solid var(--cream-dark)',
          display: 'flex', flexDirection: 'column', gap: 2, padding: '12px 5% 16px',
        }}>
          {links.map(l => (
            <a key={l.href} href={l.href}
              onClick={() => setMenuOpen(false)}
              style={{
                padding: '10px 12px', textDecoration: 'none',
                color: 'var(--ink-mid)', fontSize: 15,
                borderRadius: 'var(--radius-sm)',
              }}
            >{l.label}</a>
          ))}
          <a href="#" style={{ padding: '10px 12px', color: 'var(--red)', fontWeight: 600, textDecoration: 'none', fontSize: 15 }}>
            Entrar / Registrarse
          </a>
        </div>
      )}

      <style>{`
        @media (max-width: 900px) {
          .nav-desktop { display: none !important; }
          .hamburger { display: flex !important; }
        }
      `}</style>
    </>
  )
}
