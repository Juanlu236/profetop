import Navbar from './components/Navbar'
import ScrollReveal from './components/ScrollReveal'
import Hero from './sections/Hero'
import { SearchBar, CatNav } from './sections/Search'
import Categories from './sections/Categories'
import Featured from './sections/Featured'
import { SellBanner, Testimonials, Newsletter, Footer } from './sections/Extras'

export default function Home() {
  return (
    <>
      <Navbar />
      <ScrollReveal />
      <main>
        <Hero />
        <SearchBar />
        <CatNav />
        <Categories />
        <Featured />
        <SellBanner />
        <Testimonials />
        <Newsletter />
      </main>
      <Footer />
    </>
  )
}
