# Profetop.es — Next.js

Marketplace educativo para docentes españoles de primaria y secundaria.

## Estructura del proyecto

```
profetop/
├── app/
│   ├── components/
│   │   ├── Navbar.tsx        # Navegación principal (sticky + responsive)
│   │   └── ScrollReveal.tsx  # Animaciones de aparición al hacer scroll
│   ├── sections/
│   │   ├── data.ts           # Datos: categorías, asignaturas, recursos
│   │   ├── Hero.tsx          # Sección hero con gradiente y estadísticas
│   │   ├── Search.tsx        # Barra de búsqueda + navegación por categorías
│   │   ├── Categories.tsx    # Las 5 secciones de recursos con asignaturas
│   │   ├── Featured.tsx      # Recursos más vendidos
│   │   └── Extras.tsx        # Banner vender, testimonios, newsletter, footer
│   ├── globals.css           # Variables CSS, tipografía, animaciones
│   ├── layout.tsx            # Layout raíz con metadatos SEO
│   └── page.tsx              # Página principal
├── package.json
├── next.config.js
└── tsconfig.json
```

## Instalación

```bash
# 1. Instala las dependencias
npm install

# 2. Inicia el servidor de desarrollo
npm run dev

# 3. Abre en el navegador
http://localhost:3000
```

## Despliegue en Vercel (recomendado — gratis)

```bash
# 1. Instala Vercel CLI
npm install -g vercel

# 2. Despliega
vercel

# 3. Para producción
vercel --prod
```

O simplemente conecta el repositorio de GitHub a https://vercel.com y se despliega automáticamente con cada cambio.

## Despliegue en Netlify

```bash
# 1. Construye el proyecto
npm run build

# 2. Arrastra la carpeta /out a netlify.com/drop
```

## Personalización

### Colores (app/globals.css)
- `--red`: #A32D2D — color principal Profetop
- `--red-dark`: #791F1F — hover y acentos
- `--cream`: #FBF8F5 — fondo general

### Añadir asignaturas (app/sections/data.ts)
Edita el array `categories` para añadir o quitar asignaturas en cualquier categoría.

### Añadir recursos destacados (app/sections/data.ts)
Edita el array `featuredResources` con los recursos que quieras mostrar.

## Para añadir pagos reales
Integra **Stripe** siguiendo la documentación oficial:
- https://stripe.com/docs/connect (para marketplace con múltiples vendedores)

## Dominio profetop.es
Una vez desplegado en Vercel o Netlify, conecta tu dominio desde el panel de cada plataforma.
